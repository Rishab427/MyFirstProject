class Demo1
{
public static void main(String arv[])
  {
  int a=5;
  System.out.println("Hello"+a);
  }
}


//compile-> javac -d . -cp "c:\Program Files (x86)\Java\jre1.8.0_101\bin" Demo.java
//run    ->