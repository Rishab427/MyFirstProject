class Demo
{
static class Demo2
{
//static int a =10;

public static void main(String arv[])
  {
  int r =5;
  for(int i=0;i<r;i++)
    {
    for(int j=0;j<(r-i-1);j++)
      System.out.print(" ");
    
    for(int k=0; k<(2*(i+1)-1) ;k++)
      System.out.print("*");
    
    System.out.println();
    }
  }
}
}