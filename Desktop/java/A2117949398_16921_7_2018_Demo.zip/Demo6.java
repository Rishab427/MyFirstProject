import java.util.Scanner;

class Student
{
String name;
String fatherName;
int rollNo;
String section, college, address;

static Scanner sc = new Scanner(System.in);

void input()
  {
  System.out.println("Enter name");
  name = sc.nextLine();
  System.out.println("Enter father name");
  fatherName = sc.nextLine();
  
  System.out.println("Enter rollNo");
  rollNo = sc.nextInt();
  sc.nextLine();
  System.out.println("Enter section");
  section = sc.nextLine();
  System.out.println("Enter college");
  college = sc.nextLine();
  System.out.println("Enter address");
  address = sc.nextLine();
  }

void display()
  {
  System.out.println("name = "+name);
  System.out.println("fatherName = "+fatherName);
  System.out.println("rollNo = "+rollNo);
  System.out.println("section = "+section);
  System.out.println("college = "+college);
  System.out.println("address = "+address);
  }
public static void main(String arv[])
  {
  int a=1;
  
  Student st = new Student();
  while((a>0)&&(a<3))
    {
    System.out.println("Enter\n1. Input\n2.Display \n3.Exit");
    a = sc.nextInt();
    sc.nextLine();
    switch(a)
      {
      case 1:
        st.input();
        break;
      case 2:
        st.display();
        break;
      default:
        System.out.println("Wrong input");
      }
    }
  }
}