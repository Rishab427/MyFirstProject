class Account
{
private int id;
private double balance;
private double annualInterestRate ;
static int counter =100;
Account()
  {
  id = ++counter;
  balance = 500.0;
  annualInterestRate = 4;
  }
Account(int id, double bal)
  {
  this.id = id;
  balance = bal;
  annualInterestRate = 4;
  }
double getMonthlyInterest()
  {
  return (balance*annualInterestRate*1)/(100*12);
  }
void withdraw(double w)
  {
  
  }
void deposit(double d)
  {
  
  }
}