import java.util.Scanner;

class Student
{
public static void main(String arv[])
  {
  
  Scanner sc = new Scanner(System.in);
  
  System.out.println("Enter name");
  String name = sc.nextLine();

  System.out.println("Enter rollNo");
  int rollNo = sc.nextInt();
  sc.nextLine();
  System.out.println("Enter address");
  String address = sc.nextLine();
 
  System.out.println("name = "+name);
  System.out.println("rollNo = "+rollNo);
  System.out.println("address = "+address);
  }
}