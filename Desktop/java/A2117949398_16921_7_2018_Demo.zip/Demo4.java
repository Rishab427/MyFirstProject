class Demo
{
public static void main(String arv[])
  {
  int r = 10;
  for(int i=0; i<r;i++)
    {
    for(int j=0;j <r-1-i ; j++)
      System.out.print(" ");
    
    for(int k= 0; k< (2*(i+1)-1);k++)
      System.out.print("*");
    
    System.out.print("\n");
    
    }
  }
}
/*               *
               + * +
             * * * * *
           + * * * * * +
         * * * * * * * * *
         + + + + + + + +
