
class Demo
{
int a = 10; 
void m(Demo ob)
  {
  ob.a = 20;
  a = 30;
  }
public static void main(String arv[])
  {
  Demo obj = new Demo();
  Demo obj2 = new Demo();
  
  obj.m(obj2);
  System.out.println("a = "+obj2.a);
  }
}






