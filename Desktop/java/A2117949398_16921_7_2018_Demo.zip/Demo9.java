class Demo
{
static int a;
static 
  {
  System.out.println("static block 1");
  }
static void m()
  {
  System.out.println("static Method 1");
  }
void m1()
  {
  System.out.println("non-static Method ");
  }  
  {
  System.out.println("Instance block 2");
  }
Demo()
  {
  System.out.println("Constructor");
  }
Demo(int a)
  {
  System.out.println("Constructor2");
  }
int b;
}

class Demo2
{
public static void main(String arv[])
  {
  System.out.println("Main");
 // Demo obj = new Demo();
  //Demo obj2 = new Demo(2);
  //Demo.m();
  //Demo.m();
  System.out.println("a = "+Demo.a);
  }
}
