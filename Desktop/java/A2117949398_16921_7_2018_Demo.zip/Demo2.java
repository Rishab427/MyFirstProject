 class Demo
{
public static void main(String arv[])
  {
  int b = 5;
  int c = b++ + ++b;
  
  System.out.println("b = "+b);
  System.out.println("c = "+c);
  }
}