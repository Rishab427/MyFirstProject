
class Demo
{
static
  {
  System.out.println("static");
  }
Demo()
  {
  System.out.println("Constructor");
  }  
static
  {
  System.out.println("static2");
  }
void m1()
  {
  System.out.println("Method");
  }
}
class Demo2
{
public static void main(String arv[])
  {
  Demo obj =new Demo();
  Demo obj2 =new Demo();
  //obj.m1();
  System.out.println("Main");
  }
}
